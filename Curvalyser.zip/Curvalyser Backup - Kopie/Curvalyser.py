#!/usr/bin/env python
from CurvalyserLib import CurvalyserCLI
CurvalyserCLI()
